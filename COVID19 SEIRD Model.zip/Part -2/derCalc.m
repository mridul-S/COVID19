function derivatives=derCalc(A,X)

derivatives=A*X;
end