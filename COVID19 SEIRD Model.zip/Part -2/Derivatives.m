function R=Derivatives(A,theta_vec)


R=A*theta_vec;


end