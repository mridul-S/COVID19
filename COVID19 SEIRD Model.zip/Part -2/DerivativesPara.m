function R=DerivativesPara(A,theta_vec)


R=A*theta_vec;

end